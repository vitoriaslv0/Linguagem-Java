package POO.operacoes;

public interface principal {
    double calcular(double a, double b);
}
