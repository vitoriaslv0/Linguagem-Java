package POO.operacoes;

public class multiplica implements principal {
    @Override
    public double calcular(double a, double b) {
        return a * b;
    }
}
